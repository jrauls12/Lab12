﻿using System;

class Program
{
    static void Main()
    {
        
        int[] notasalumnos = new int[15];

        for (int n = 0; n < 15; n++)
        {
            
            Console.WriteLine("Ingrese las 15 notas: ");
            notasalumnos[n] = int.Parse(Console.ReadLine());
        }

        double promedio = 0;
        double sumanotas = 0;
        for (int j = 0; j < 15; j++)
        {
            sumanotas = sumanotas + notasalumnos[j];
        }

        promedio = sumanotas / 15;
        Console.WriteLine("El promedio de la suma de las notas es" + promedio);


    }
}
